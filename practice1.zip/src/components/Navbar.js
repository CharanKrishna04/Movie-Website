import React from 'react';
import {Link} from 'react-router-dom';
function Navbar() {
    return (
        <div>
            <nav className="navbar navbar-light bg-dark mb-5">
                <div className="container">
                <div className="navbar-header">
                    <Link className="navbar-brand text-white text-lg brand-text" to="/">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSY1I4wiMVyEn_NMlAyKOkjXIYlcatvmLOHbcDE-dJYLCXeYpQP" height="100" width="150"/>
                    </Link>
                    
                </div>
                <h2 >CinemaTribe.</h2>
                <h4>Movies & More.</h4>
                <ul className="navbar-nav ml-auto text-light d-inline-block">
                    <li className="nav-item d-inline-block mr-4">
                        <i className="fab fa-imdb fa-5x" id="imdb-logo"/>
                        
                    </li>
                    <li className="nav-item d-inline-block mr-4">
                        <i className="fab fa-react fa-5x" id="react-logo"/>
                    </li>
                </ul>
                </div>
            </nav>

        </div>
    )
}

export default Navbar;


