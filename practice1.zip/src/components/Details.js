import React from  'react'
import axios from 'axios'

class Details extends React.Component{
    constructor(props) {
        super(props);
        this.state = { 
            result:[],
         }
        }
    componentDidMount()
    {
        const {imdbID}=this.props.match.params;
        const Api='f1c23fa4'
        const Url = `http://www.omdbapi.com/?apikey=${Api}&i=${imdbID}`
        axios.get(Url)
        .then(response =>
          {
            console.log(response)
             console.log(response.data)
            this.setState({
              result:response.data
            })
          })
    }
    render() {
        const{
            Poster,
            Title,
            Rated, 
            Released, 
            Runtime,
            Genre,
            Director,
            Writer, 
            Actors,
            Plot, 
            Country,
            Awards,
           
            Language
        }=this.state.result;
        return (
        <div className="container">
                <div className="row">
                     <div className="col-md-4 card card-body">
                        <img className="w-100 mb-2" src={Poster} alt="Poster"/>                             
                    </div>
                    <div className="col-md-8">
                        <h2 className="mb-4">  </h2> <strong><h1>{Title}</h1></strong>
                        <ul className="list-group">
                            <li className="list-group-item">
                                <strong>Genre:</strong> {Genre}
                            </li>
                            <li className="list-group-item">
                            <strong>Released:</strong> {Released}
                            </li>
                            
                            <li className="list-group-item">
                            <strong>Director:</strong> {Director}
                            </li>
                            <li className="list-group-item">
                            <strong>Writer:</strong> {Writer}
                            </li>
                            <li className="list-group-item">
                            <strong>Actors:</strong>{Actors}
                            </li>
                            <li className="list-group-item">
                            <strong>Language:</strong>{Language}
                            </li>
                            <li className="list-group-item">
                            <strong>Runtime:</strong> {Runtime}
                            </li>
                            <li className="list-group-item">
                            <strong>Rated:</strong> {Rated}
                            </li>
                            <li className="list-group-item">
                            <strong>Country:</strong> {Country}
                            </li>
                            <li className="list-group-item">
                            <strong>Plot:</strong>{Plot}
                            </li>
                            <li className="list-group-item">
                            <strong>Awards:</strong> {Awards}
                            </li>
                        </ul>
                    </div>
                </div>
          </div>
        )
    }

}
export default Details