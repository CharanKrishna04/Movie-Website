import React, { Component } from 'react';
import axios from 'axios';
import Popup from 'reactjs-popup';
import {BrowserRouter as Router,Route,Link} from 'react-router-dom'
class Search extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            name:"",
            result:[],
         }
    }
    handleClick = (e) =>
  {
      
      const Api='fc9f7a47'
      const Url = `http://www.omdbapi.com/?apikey=${Api}&s=${this.state.name}`
      axios.get(Url)
      .then(response =>
        {
          console.log(response)
           console.log(response.data)
           console.log(response.data.Search)
           console.log(response.data.totalResults)

          this.setState({
            result:response.data
          })
        })
          .catch(err => console.log("err"))
    }
    handleChange =(e)=>
    {
        this.setState({
            name:e.target.value
        })                                                                                                             
    }
    render() {
        console.log("ddddddddddddddddddddddddddddddddddddd")
        console.log(this.state.result)
      return (
                
                 <div className="jumbotron jumbotron-fluid mt-5 text-center" align="center">
                    <h1>
                     Search for a movie,TV series ... 
                     </h1> 
                    <i className="fa fa-search"  /><input type='text' placeholder="Explore..."  width="10000" onChange={this.handleChange} />
                    <br/>
                    <br/>
                      
                    <button type='submit' className="btn btn-primary btn-bg mt-3" onClick={this.handleClick} >Search</button>
                    
                    {this.state.result.Response === 'True'?
                    this.state.result.Search.map(movie=>
                    <Link to={`/${movie.imdbID}`}>
                            {/* <div> */}
                            {/* <img src={movie.Poster}></img>  */}
                            {/* <p>{movie.Title}-{movie.Year}</p> */}
                            <div align="center">
                            <div className="col-md-3 mb-5" align="center">
                <div className="card card-body bg-dark text-center h-100" align="center">
                    <img className="w-100 mb-2" src={movie.Poster} alt="Movie Cover" />
                    <h5 className="text-light card-title">
                        {movie.Title} 
                    </h5>
                    
                            <Link className="btn btn-primary" to={movie.imdbID} >
                             MovieDetails<b>></b> 
                            </Link>
                            </div>
                             </div>
                             </div>
                            {/* </div>*/}</Link>):null} 
                           
                        
                        </div>
                      
               
      )
    }
  }

export default Search