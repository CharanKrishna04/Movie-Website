import React from 'react';
// import logo from './logo.svg';
import './App.css';
 import Greet from './components/Greet'
import Hello from './components/Hello'
import Search from './components/Search'
import Details from './components/Details'
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import {BrowserRouter as  Router,Route,} from "react-router-dom"
function App() {
  return (
    
    <Router>
    <div className="App">
      <Navbar />
      <Route path='/' exact component={Hello}/>
      <Route path='/' exact component={Search}/>
      <Route path='/:imdbID' exact component={Details}/>
      <Footer/>
    </div>
    </Router>
  );
}
export default App;